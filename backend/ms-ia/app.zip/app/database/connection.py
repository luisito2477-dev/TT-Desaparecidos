import os
from dotenv import load_dotenv
from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from typing import Generator


# Cargar variables del archivo .env
load_dotenv()

# Construction de la URL de conexion PostgreSQL
DB_USER : str = os.getenv("DB_USER")
DB_PASSWORD: str = os.getenv("DB_PASSWORD")
DB_HOST: str = os.getenv("DB_HOST")
DB_PORT: str = os.getenv("DB_PORT")
DB_NAME: str = os.getenv("DB_NAME")

SQLALCHEMY_DATABASE_URL: str = (
    f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

print(f"URL papa: {SQLALCHEMY_DATABASE_URL}")

# crea la conexion entre la API y el PostgreSQL
engine: Engine = create_engine(SQLALCHEMY_DATABASE_URL)

# crea fabrica de sesiones para hacer consultas
# autocommit = False : evita que los cambios se guarden solos
# autoflush = False : Evita que SQLAlchemy envie cambios a la base de datos
SessionLocal: sessionmaker = sessionmaker(bind=engine, autoflush=False, autocommit=False)

# Clase Base. Todos los modelos heredaran de esta clase para que el SQLAlchemy los reconozca
Base = declarative_base()

def get_db() -> Generator[Session, None, None]:
    """
    Crea y cierra una sesion de base de datos por peticion
    """
    db: Session = SessionLocal()
    try:
        yield db # entrega la sesion a la ruta que se pidio
    finally:
        db.close()